<?php

namespace App\Http\Controllers;

use App\Models\Agen;
use App\Models\Kedatangan;
use App\Models\Pembelian;
use App\Models\Provinsi;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class EntriAgenController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $title = "Kelola Data Pembelian";
        $kedatangan = Kedatangan::with('agen', 'sales')
            ->where('id_sales', Auth::id())
            ->where('selesai', 0)
            ->get();
        return view('sales.agen.index', compact('title', 'kedatangan'));
    }

    public function tambah()
    {
        $title = "Tambah Data Pembelian";
        $provinsi = Provinsi::all();
        return view('sales.agen.tambah', compact('title', 'provinsi'));
    }

    public function store(Request $request)
    {
        // olah file
        // get nama file
        try {
            if ($request->file_upload == null) {
                $file_path = null;
            } else {
                $file = $request->file('file_upload');
                $file_name = time() . '_' . $file->getClientOriginalName();
                $file_path = $file->storeAs('uploads', $file_name, 'public');
                
            }

            $query = Kedatangan::insert([
                    'id_sales' => Auth::id(),
                    'id_agen' => $request->id_agen,
                    'foto_path_sales' =>$file_path,
                    'selesai' => 0
                ]);


            if ($query) {
                return redirect('entri')->with('success', 'berhasil ditambah');
            } else {
                return redirect()->back()->with('alert', 'gagal ditambah');
            }
        } catch (\Throwable $th) {
            return redirect()->back()->with('alert', 'gagal ditambah');
        }
    }
}
