<div class="left side-menu ">
  <div class="sidebar-inner slimscrollleft">

    <!-- User -->
    <div class="user-box">
      <div class="user-img">
        <img src="<?php echo e(asset('adminto/images/users/avatar-1.jpg')); ?>" alt="user-img" title="Mat Helme" class="rounded-circle img-thumbnail img-responsive">
        <div class="user-status online"><i class="mdi mdi-adjust"></i></div>
      </div>
      <h5><a href="#"> <?php echo e(Auth::user()->username); ?></a> </h5>
      <ul class="list-inline">


        <li class="list-inline-item">
          <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
            <?php echo e(__('Logout')); ?>

          </a>

          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
          </form>
        </li>
      </ul>
    </div>
    <!-- End User -->

    <!--- Sidemenu -->
    <div id="sidebar-menu">
      <ul>
        <li class="text-muted menu-title">Navigation</li>
        <li>
          <a href="<?php echo e(('/')); ?>" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Dashboard </span> </a>
        </li>
        <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>


        <li class="has_sub">
          <a href="javascript:void(0);" class="waves-effect"><i class=" mdi mdi-account-multiple"></i> <span> Data User </span> <span class="fa menu-arrow"></span></a>
          <ul class=" list-unstyled">
            <li><a href="<?php echo e(route ('sales.index', 'Sales')); ?>">Sales</a></li>
            <li><a href="<?php echo e(route ('agen.index')); ?>">Outlet</a></li>
          </ul>
        </li>

        <li>
          <a href="<?php echo e(route ('barang.index')); ?>" class="waves-effect"><i class="mdi mdi-cube"></i> <span> Data Barang </span> </a>
        </li>

        <li>
          <a href="<?php echo e(route ('peringkat.index')); ?>" class="waves-effect"><i class="mdi mdi-star-circle"></i> <span> Peringkat </span> </a>
        </li>

        <li>
          <a href="<?php echo e(route ('kehadiran.index')); ?>" class="waves-effect"><i class="mdi mdi-calendar-check"></i> <span> Kehadiran </span> </a>
        </li>

        <?php endif; ?>

        <?php if(auth()->check() && auth()->user()->hasRole("sales")): ?>

        <li>
          <a href="<?php echo e(route ('entri.index')); ?>" class="waves-effect"><i class="mdi mdi-format-font"></i> <span> Entri Outlet </span> </a>
        </li>

        <li>
          <a href="<?php echo e(route ('kehadiran.index')); ?>" class="waves-effect"><i class="mdi mdi-calendar-check"></i> <span> Kehadiran </span> </a>
        </li>

        <?php endif; ?>

        <?php if(auth()->check() && auth()->user()->hasRole("agen")): ?>

        <li>
          <a href="<?php echo e(route ('pembelian.index')); ?>" class="waves-effect"><i class="mdi mdi-cart"></i> <span> Pembelian </span> </a>
        </li>
        <li>
          <a href="<?php echo e(route ('peringkat.index')); ?>" class="waves-effect"><i class="mdi mdi-star-circle"></i> <span> Peringkat </span> </a>
        </li>

        <?php endif; ?>





      </ul>
      <div class="clearfix"></div>
    </div>
    <!-- Sidebar -->
    <div class="clearfix"></div>

  </div>

</div>
<!-- Left Sidebar End -->



<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
  <!-- Start content -->
  <div class="content">
    <div class="container-fluid">


    </div> <!-- container -->

  </div> <!-- content -->

  <footer class="footer text-right">
    2021 - GGSP COMPETITION PEKANBARU
  </footer>

</div><?php /**PATH C:\xampp\htdocs\GGSP-Pekanbaru\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>