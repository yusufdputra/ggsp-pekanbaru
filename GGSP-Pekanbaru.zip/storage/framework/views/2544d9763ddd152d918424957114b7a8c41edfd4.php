<div class="left side-menu">
  <div class="sidebar-inner slimscrollleft">

    <!-- User -->
    <div class="user-box">
      <div class="user-img">
        <img src="<?php echo e(asset('adminto/images/users/avatar-1.jpg')); ?>" alt="user-img" title="Mat Helme" class="rounded-circle img-thumbnail img-responsive">
        <div class="user-status online"><i class="mdi mdi-adjust"></i></div>
      </div>
      <h5><a href="#"> <?php echo e(Auth::user()->name); ?></a> </h5>
      <ul class="list-inline">


        <li class="list-inline-item">
          <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
            <?php echo e(__('Logout')); ?>

          </a>

          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
          </form>
        </li>
      </ul>
    </div>
    <!-- End User -->

    <!--- Sidemenu -->
    <div id="sidebar-menu">
      <ul>
        <li class="text-muted menu-title">Navigation</li>
        <li>
          <a href="<?php echo e(('/')); ?>" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Dashboard </span> </a>
        </li>
        <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
        <li>
          <a href="<?php echo e(route ('pegawai.index')); ?>" class="waves-effect"><i class="mdi mdi-account-multiple"></i> <span> Data Pegawai </span> </a>
        </li>

        <li>
          <a href="<?php echo e(route ('agenda.index')); ?>" class="waves-effect"><i class="mdi mdi-view-agenda"></i> <span> Agenda </span> </a>
        </li>
        <li>
          <a href="<?php echo e(route ('bidang.index')); ?>" class="waves-effect"><i class="mdi mdi-cube"></i> <span> Bidang </span> </a>
        </li>

        <?php endif; ?>

        <?php if(auth()->check() && auth()->user()->hasRole("pegawai")): ?>

        <li>
          <a href="<?php echo e(route ('agenda.index')); ?>" class="waves-effect"><i class="mdi mdi-format-font"></i> <span> Agenda </span> </a>
        </li>

        <?php endif; ?>





      </ul>
      <div class="clearfix"></div>
    </div>
    <!-- Sidebar -->
    <div class="clearfix"></div>

  </div>

</div>
<!-- Left Sidebar End -->



<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
  <!-- Start content -->
  <div class="content">
    <div class="container-fluid">


    </div> <!-- container -->

  </div> <!-- content -->

  <footer class="footer text-right">
    2021 - Dinas Perhubungan Kampar Team
  </footer>

</div><?php /**PATH C:\xampp\htdocs\SIAP-DINPER\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>