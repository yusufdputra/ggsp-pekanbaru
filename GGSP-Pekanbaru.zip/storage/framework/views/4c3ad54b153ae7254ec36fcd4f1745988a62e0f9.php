

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-12">
    <div class="card-box table-responsive">

      <?php if(auth()->check() && auth()->user()->hasRole('agen')): ?>
      <div class="alert alert-success">
        Kamu Berada Diperingkat : <strong> <?php echo e($peringkat); ?></strong>
      </div>

      <?php endif; ?>

      <?php if(\Session::has('alert')): ?>
      <div class="alert alert-danger">
        <div><?php echo e(Session::get('alert')); ?></div>
      </div>
      <?php endif; ?>

      <?php if(\Session::has('success')): ?>
      <div class="alert alert-success">
        <div><?php echo e(Session::get('success')); ?></div>
      </div>
      <?php endif; ?>


      <table id="datatable-buttons"  class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
          <tr>

            <?php if(auth()->check() && auth()->user()->hasAnyRole('sales|admin')): ?>
            <th>No</th>
            <th>Username</th>
            <th>Area Office</th>
            <th>Kode Outlet</th>
            <th>Nama Outlet</th>
            <th>GGSP Type</th>
            <th>Jenis Toko</th>
            <th>Pic Outlet</th>
            <th>Nomor Hp</th>
            <th>Alamat</th>
            <th>Kabupaten</th>
            <th>Kecamatan</th>
            <th>Kelurahan</th>
            <th>Poin</th>
            <?php else: ?>
            <th>No</th>
            <th>Area Office</th>
            <th>Kode Outlet</th>
            <th>Nama Outlet</th>
            <th>Kabupaten</th>
            <th>Kecamatan</th>
            <th>Kelurahan</th>
            <th>Poin</th>
            <?php endif; ?>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <tr>
            <?php if(auth()->check() && auth()->user()->hasAnyRole('sales|admin')): ?>

            <td><?php echo e($key+1); ?></td>
            <td><?php echo e(($value->user['username'])); ?></td>
            <td><?php echo e(strtoupper($value->kabupaten['nama'])); ?></td>
            <td><?php echo e(strtoupper($value->kode_outlet)); ?></td>
            <td><?php echo e(strtoupper($value->name)); ?></td>
            <td><?php echo e(strtoupper($value->ggsp_type)); ?></td>
            <td><?php echo e(strtoupper($value->jenis_toko)); ?></td>
            <td><?php echo e(strtoupper($value->pic_outlet)); ?></td>
            <td><?php echo e(strtoupper($value->nomor_hp)); ?></td>
            <td><?php echo e(strtoupper($value->nama_jalan)); ?></td>
            <td><?php echo e(strtoupper($value->kabupaten['nama'])); ?></td>
            <td><?php echo e(strtoupper($value->kecamatan['nama'])); ?></td>
            <td><?php echo e(strtoupper($value->kelurahan['nama'])); ?></td>
            <td>
            
            <?php echo e($value['poin']); ?>

            <a href="<?php echo e(route('pembelian.history',$value->user['id'])); ?>" class="btn btn-success btn-sm "><i class="fa fa-eye"></i></a>
            
            </td>
            <?php else: ?>

            <td><?php echo e($key+1); ?></td>

            <td><?php echo e(strtoupper($value->kabupaten['nama'])); ?></td>
            <td><?php echo e(strtoupper($value->kode_outlet)); ?></td>
            <td><?php echo e(strtoupper($value->name)); ?></td>
            <td><?php echo e(strtoupper($value->kabupaten['nama'])); ?></td>
            <td><?php echo e(strtoupper($value->kecamatan['nama'])); ?></td>
            <td><?php echo e(strtoupper($value->kelurahan['nama'])); ?></td>
            <td>
            <?php echo e($value['poin']); ?>

            </td>
            <?php endif; ?>


          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GGSP-Pekanbaru\resources\views/admin/peringkat/index.blade.php ENDPATH**/ ?>