

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-12">
    <div class="card-box table-responsive">
      <div class="align-items-center">

        <a href="#tambah-modal" data-animation="sign" data-plugin="custommodal" data-overlaySpeed="100" data-overlayColor="#36404a" class="btn btn-primary m-l-10 waves-light  mb-5">Tambah</a>

      </div>



      <?php if(\Session::has('alert')): ?>
      <div class="alert alert-danger">
        <div><?php echo e(Session::get('alert')); ?></div>
      </div>
      <?php endif; ?>

      <?php if(\Session::has('success')): ?>
      <div class="alert alert-success">
        <div><?php echo e(Session::get('success')); ?></div>
      </div>
      <?php endif; ?>


      <table id="datatable" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
          <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Username</th>
            <?php if($jenis == 'Agen'): ?>
            <th>Alamat</th>
            <?php endif; ?>
            <th>Action</th>
          </tr>
        </thead>

        <tbody>

          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <tr>
            <td><?php echo e($key+1); ?></td>
            <td><?php echo e($value->name); ?></td>
            <td><?php echo e($value->user['username']); ?></td>
            <?php if($jenis == 'Agen'): ?>
            <td>Prov. <?php echo e($value->kabupaten->provinsi['nama']); ?> - <?php echo e($value->kabupaten['nama']); ?></td>
            <?php endif; ?>
            <td>
              <a href="#edit-modal" data-animation="sign" data-plugin="custommodal" data-id='<?php echo e($value->id); ?>' data-jenis='<?php echo e($jenis); ?>' data-overlaySpeed="100" data-overlayColor="#36404a" class="btn btn-success btn-sm modal_edit"><i class="fa fa-edit"></i></a>

              <a href="#hapus-modal" data-animation="sign" data-plugin="custommodal" data-id='<?php echo e($value->id); ?>' data-jenis='<?php echo e($jenis); ?>' data-iduser='<?php echo e($value->id_user); ?>' data-overlaySpeed="100" data-overlayColor="#36404a" class="btn btn-danger btn-sm hapus"><i class="fa fa-trash"></i></a>

              <a href="#edit-password" data-animation="sign" data-plugin="custommodal" data-id='<?php echo e($value->id_user); ?>' data-overlaySpeed="100" data-overlayColor="#36404a" class="btn btn-warning btn-sm modal_pw"><i class="fa fa-lock"></i></a>
            </td>
          </tr>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
      </table>
    </div>
  </div>
</div>
<!-- end row -->

<div id="tambah-modal" class="modal-demo">
  <button type="button" class="close" onclick="Custombox.close();">
    <span>&times;</span><span class="sr-only">Close</span>
  </button>

  <div class="custom-modal-text text-left">

    <div class="text-center">
      <h4 class="text-uppercase font-bold mb-0">Tambah <?php echo e($jenis); ?></h4>
    </div>
    <div class="p-20">

      <form class="form-horizontal m-t-20" enctype="multipart/form-data" action="<?php echo e(route('user.store')); ?>" method="POST">
        <?php echo e(csrf_field()); ?>


        <input type="hidden" name="jenis" value="<?php echo e($jenis); ?>" id="">

        <div class="form-group">
          <label for="">Nama</label>
          <div class="col-xs-12">
            <input class="form-control" type="text" autocomplete="off" name="nama" required="" placeholder="Nama">
          </div>
        </div>

        <div class="form-group">
          <label for="">Username</label>
          <div class="col-xs-12">
            <input class="form-control" type="text" autocomplete="off" name="username" required="" placeholder="Nama">
          </div>
        </div>

        <?php if($jenis == 'Agen'): ?>
        <div class="form-group">
          <label for="">Provinsi</label>
          <div class="col-xs-12">
            <select required class="form-control " id="provinsi" name="provinsi">
              <option disabled selected>Pilih..</option>
              <?php $__currentLoopData = $provinsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($value->id_prov); ?>"><?php echo e($value->nama); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label for="">Kabupaten</label>
          <div class="col-xs-12">
            <select required class="form-control" id="kabupaten" name="kabupaten">

            </select>
          </div>
        </div>

        <?php endif; ?>

        <div class="form-group">
          <label for="">Password</label>
          <div class="col-xs-12">
            <input class="form-control" autocomplete="off" type="text" name="password" required="" placeholder="Password">
          </div>
        </div>


        <div class="form-group text-center m-t-30">
          <div class="col-xs-12">
            <button class="btn btn-success btn-bordred btn-block waves-effect waves-light" type="submit">Tambah</button>
          </div>
        </div>


      </form>

    </div>
  </div>

</div>

<div id="edit-modal" class="modal-demo">
  <button type="button" class="close" onclick="Custombox.close();">
    <span>&times;</span><span class="sr-only">Close</span>
  </button>

  <div class="custom-modal-text text-left">

    <div class="text-center">
      <h4 class="text-uppercase font-bold mb-0">Edit <?php echo e($jenis); ?></h4>
    </div>
    <div class="p-20">

      <form class="form-horizontal m-t-20" action="<?php echo e(route('user.update')); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="id" id="edit_id">

        <input type="hidden" name="jenis" id="edit_jenis">

        <div class="form-group">
          <label for="">Nama</label>
          <div class="col-xs-12">
            <input class="form-control" type="text" autocomplete="off" id="edit_nama" name="nama" required="" placeholder="Nama">
          </div>
        </div>

        <?php if($jenis == 'Agen'): ?>
        <div class="form-group">
          <label for="">Provinsi</label>
          <div class="col-xs-12">
            <select required class="form-control " id="edit_provinsi" name="provinsi">
              <option disabled selected>Pilih..</option>
              <?php $__currentLoopData = $provinsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($value->id_prov); ?>"><?php echo e($value->nama); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label for="">Kabupaten</label>
          <div class="col-xs-12">
            <select required class="form-control" id="edit_kabupaten" name="kabupaten">

            </select>
          </div>
        </div>

        <?php else: ?>

        <input type="hidden" id="provinsi">
        <input type="hidden" id="edit_provinsi">
        <?php endif; ?>

        <div class="form-group text-center m-t-30">
          <div class="col-xs-12">
            <button class="btn btn-success btn-bordred btn-block waves-effect waves-light" type="submit">Ubah</button>
          </div>
        </div>


      </form>

    </div>
  </div>

</div>

<div id="edit-password" class="modal-demo">
  <button type="button" class="close" onclick="Custombox.close();">
    <span>&times;</span><span class="sr-only">Close</span>
  </button>

  <div class="custom-modal-text text-left">

    <div class="text-center">
      <h4 class="text-uppercase font-bold mb-0">Reset Password <?php echo e($jenis); ?></h4>
    </div>
    <div class="p-20">

      <form class="form-horizontal m-t-20" action="<?php echo e(route('user.resetpw')); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="id" id="pw_id">


        <div class="form-group">
          <label for="">Password Baru</label>
          <div class="col-xs-12">
            <input class="form-control" type="text" autocomplete="off" name="password" required="" placeholder="Masukkan Password Baru">
          </div>
        </div>


        <div class="form-group text-center m-t-30">
          <div class="col-xs-12">
            <button class="btn btn-success btn-bordred btn-block waves-effect waves-light" type="submit">Reset</button>
          </div>
        </div>


      </form>

    </div>
  </div>

</div>

<div id="hapus-modal" class="modal-demo">
  <button type="button" class="close" onclick="Custombox.close();">
    <span>&times;</span><span class="sr-only">Close</span>
  </button>

  <div class="custom-modal-text">

    <div class="text-center">
      <h4 class="text-uppercase font-bold mb-0">Hapus <?php echo e($jenis); ?></h4>
    </div>
    <div class="p-20">

      <form class="form-horizontal m-t-20" enctype="multipart/form-data" action="<?php echo e(route('user.hapus')); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <div>
          <input type="hidden" id='id_hapus' name='id'>
          <input type="hidden" id='id_user_hapus' name='id_user'>
          <input type="hidden" id='jenis_hapus' name='jenis'>
          <h5 id="exampleModalLabel">Apakah anda yakin ingin mengapus <?php echo e($jenis); ?> ini?</h5>
        </div>

        <div class="form-group text-center m-t-30">
          <div class="col-xs-6">
            <button type="button" onclick="Custombox.close();" class="   btn btn-primary btn-bordred btn-block waves-effect waves-light">Tidak</button>
            <button class="btn btn-danger btn-bordred btn-block waves-effect waves-light" type="submit">Hapus</button>
          </div>
        </div>


      </form>

    </div>
  </div>

</div>

<script type="text/javascript">
  $('.modal_edit').click(function() {
    var id = $(this).data('id');
    var jenis = $(this).data('jenis');
    $('#edit_kabupaten').html('')
    $.ajax({
      url: '<?php echo e(url("user/edit")); ?>',
      type: 'POST',
      data: {
        'id': id,
        'jenis': jenis,
        '_token': '<?php echo e(csrf_token()); ?>'
      },
      dataType: 'json',
      success: 'success',
      success: function(data) {
        $('#edit_id').val(id)
        $('#edit_jenis').val(data['jenis'])
        $('#edit_nama').val(data['user'][0]['name'])

        if (jenis == 'Agen') {
          $('#edit_provinsi').val(data['user'][0]['kabupaten']['id_prov'])

          data['kabupatens'].forEach(element => {

            var opt_barang = new Option(element['nama'], element['id_kab'])
            // add to option nama_barang
            $('#edit_kabupaten').append(opt_barang)
          });
          $('#edit_kabupaten').val(data['user'][0]['id_kabupaten'])
        }

      },
      error: function(data) {
        toastr.error('Gagal memanggil data! ')
      }
    })
  });

  $('.hapus').click(function() {
    var id = $(this).data('id');
    var jenis = $(this).data('jenis');
    var id_user = $(this).data('iduser');
    $('#id_hapus').val(id);
    $('#id_user_hapus').val(id_user);
    $('#jenis_hapus').val(jenis);
  });

  $('.modal_pw').click(function() {
    var id = $(this).data('id');
    $('#pw_id').val(id);
  });


  document.getElementById('provinsi').addEventListener("change", function() {
    $('#kabupaten').html('')
    $.ajax({
      url: '<?php echo e(url("GetKabupaten")); ?>/' + this.value,
      type: 'GET',
      dataType: 'json',
      success: 'success',
      success: function(data) {
        data.forEach(element => {
          var opt_barang = new Option(element['nama'], element['id_kab'])
          // add to option nama_barang
          $('#kabupaten').append(opt_barang)
        });

      },
      error: function(data) {
        toastr.error('Gagal memanggil data! ')
      }
    })
  })

  document.getElementById('edit_provinsi').addEventListener("change", function() {
    $('#edit_kabupaten').html('')
    $.ajax({
      url: '<?php echo e(url("GetKabupaten")); ?>/' + this.value,
      type: 'GET',
      dataType: 'json',
      success: 'success',
      success: function(data) {
        data.forEach(element => {
          var opt_barang = new Option(element['nama'], element['id_kab'])
          // add to option nama_barang
          $('#edit_kabupaten').append(opt_barang)
        });

      },
      error: function(data) {
        toastr.error('Gagal memanggil data! ')
      }
    })
  })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GGSP-Pekanbaru\resources\views/admin/user/index.blade.php ENDPATH**/ ?>