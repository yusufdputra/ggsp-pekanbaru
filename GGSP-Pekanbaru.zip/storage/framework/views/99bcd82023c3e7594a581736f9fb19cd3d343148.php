

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-12">
    <div class="card-box table-responsive">
      <div class="align-items-center">

        <a href="<?php echo e(route('entri.tambah')); ?>" class="btn btn-primary m-l-10 waves-light  mb-5">Tambah</a>

      </div>

      <?php if(\Session::has('alert')): ?>
      <div class="alert alert-danger">
        <div><?php echo e(Session::get('alert')); ?></div>
      </div>
      <?php endif; ?>

      <?php if(\Session::has('success')): ?>
      <div class="alert alert-success">
        <div><?php echo e(Session::get('success')); ?></div>
      </div>
      <?php endif; ?>


      <table id="datatable" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
          <tr>
            <th>No</th>
            <th>Area Office</th>
            <th>Kode Outlet</th>
            <th>Nama Outlet</th>
            <th>GGSP Type</th>
            <th>Jenis Toko</th>
            <th>Pic Outlet</th>
            <th>Nomor Hp</th>
            <th>Alamat</th>
            <th>Kabupaten</th>
            <th>Kecamatan</th>
            <th>Kelurahan</th>
          </tr>
        </thead>

        <tbody>


          <?php $__currentLoopData = $kedatangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <tr>
            <td><?php echo e($key+1); ?></td>
            <td><?php echo e(strtoupper($value->agen->kabupaten['nama'])); ?></td>
            <td><?php echo e(strtoupper($value->agen['kode_outlet'])); ?></td>
            <td><?php echo e(strtoupper($value->agen['name'])); ?></td>
            <td><?php echo e(strtoupper($value->agen['ggsp_type'])); ?></td>
            <td><?php echo e(strtoupper($value->agen['jenis_toko'])); ?></td>
            <td><?php echo e(strtoupper($value->agen['pic_outlet'])); ?></td>
            <td><?php echo e(strtoupper($value->agen['nomor_hp'])); ?></td>
            <td><?php echo e(strtoupper($value->agen['nama_jalan'])); ?></td>
            <td><?php echo e(strtoupper($value->agen->kabupaten['nama'])); ?></td>
            <td><?php echo e(strtoupper($value->agen->kecamatan['nama'])); ?></td>
            <td><?php echo e(strtoupper($value->agen->kelurahan['nama'])); ?></td>

          </tr>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
      </table>
    </div>
  </div>
</div>
<!-- end row -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GGSP-Pekanbaru\resources\views/sales/agen/index.blade.php ENDPATH**/ ?>