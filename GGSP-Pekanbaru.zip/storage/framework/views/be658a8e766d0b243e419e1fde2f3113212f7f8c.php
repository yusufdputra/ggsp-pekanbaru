

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-12">
    <div class="card-box table-responsive">
      <div class="align-items-center">

        <a href="#" onclick="history.back()" class="btn btn-primary m-l-10 m-b-20 waves-light">Kembali</a>

      </div>

      <?php if(\Session::has('alert')): ?>
      <div class="alert alert-danger">
        <div><?php echo e(Session::get('alert')); ?></div>
      </div>
      <?php endif; ?>

      <?php if(\Session::has('success')): ?>
      <div class="alert alert-success">
        <div><?php echo e(Session::get('success')); ?></div>
      </div>
      <?php endif; ?>

      <table id="datatable" class="table table-striped table-bordered text-center " cellspacing="0" width="100%">
        <thead>
          <tr>

            <th class=" align-middle" rowspan="3">No</th>
            <th class=" align-middle" rowspan="3">Nama Sales</th>
            <th class=" align-middle" rowspan="3">Week</th>
            <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th colspan="10"><?php echo e($value->nama); ?></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <th class=" align-middle" rowspan="3">Foto</th>
          </tr>
          <tr>
            <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th colspan="2">STOK</th>
            <th colspan="2">BELANJA</th>
            <th colspan="2">DISPLAY</th>
            <th colspan="2">DISPLAY OTHER</th>
            <th colspan="2">PACK KOSONG</th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tr>
          <tr>
            <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php for($i = 0; $i < 5; $i++): ?> 
              <td>ACT</td>
              <td>POIN</td>
              <?php endfor; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tr>

        </thead>
        <tbody>
          <?php $__currentLoopData = $pembelian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <tr>
            <td><?php echo e($key+1); ?></td>
            <td><?php echo e(strtoupper($v->kedatangan->sales['name'])); ?></td>
            <td><?php echo e($v->week); ?></td>
            <?php
            $arr_stok = unserialize($v->stok);
            $arr_belanja = unserialize($v->belanja);
            $arr_display = unserialize($v->display);
            $arr_dis_other = unserialize($v->display_other);
            $arr_pack_kosong = unserialize($v->pack_kosong);
            ?>
            <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- stok -->
            <td><?php echo e($arr_stok[$key]['stok']); ?></td>
            <td><?php echo e($arr_stok[$key]['stok_poin']); ?></td>

            <!-- belanja -->
            <td><?php echo e($arr_belanja[$key]['belanja']); ?></td>
            <td><?php echo e($arr_belanja[$key]['belanja_poin']); ?></td>

            <!-- display -->
            <td><?php echo e($arr_display[$key]['display']); ?></td>
            <td><?php echo e($arr_display[$key]['display_poin']); ?></td>

            <!-- display other-->
            <td><?php echo e($arr_dis_other[$key]['dis_other']); ?></td>
            <td><?php echo e($arr_dis_other[$key]['dis_other_poin']); ?></td>

            <!-- pack kosong-->
            <td><?php echo e($arr_pack_kosong[$key]['pack_kosong']); ?></td>
            <td><?php echo e($arr_pack_kosong[$key]['pack_kosong_poin']); ?></td>

          
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <td>
              <a href="#view-image-modal" data-animation="sign" data-plugin="custommodal" data-path='<?php echo e($v->foto_display); ?>'  data-overlaySpeed="100" data-overlayColor="#36404a" class="btn btn-primary btn-sm view_image"><i class=" mdi mdi-eye"></i></a>
            </td>

          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div id="view-image-modal" class="modal-demo">
  <button type="button" class="close" onclick="Custombox.close();">
    <span>&times;</span><span class="sr-only">Close</span>
  </button>

  <div class="custom-modal-text">

    <div class="text-center">
      <h4 class="text-uppercase font-bold mb-0">Foto Sales Depan Toko</h4>
    </div>
    <div class="p-20 ">
      <div class="m-b-20" id="">
        <div class="load">
        </div>

        <div class="m-b-20" id="img_view">
        </div>
      </div>
    </div>
  </div>

</div>


<script type="text/javascript">
  $('.view_image').click(function() {
    $('#img_view').html('')
    var foto_path = $(this).data('path');
    console.log(foto_path);
    // var img_view = document.getElementById('img_view')
    $('#load').append('<i class="fa fa-spin fa-circle-o-notch"></i>')
    $('#img_view').append('<img src="../storage/' + foto_path + '" id="img_vsiew_porto" class="m-b-20 thumb-img" alt="work-thumbnail">')
    $('#load').html('')


  });

  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GGSP-Pekanbaru\resources\views/admin/pembelian/riwayat.blade.php ENDPATH**/ ?>