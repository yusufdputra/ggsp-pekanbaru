<!-- Top Bar Start -->
<div class="topbar">

<!-- LOGO -->
<div class="topbar-left">
    <a href="<?php echo e('/'); ?>" class="logo"><img src="<?php echo e(asset('adminto/images/brand/kampar.png')); ?>" width="30px" alt=""><span>Sistem <span>Informasi</span></span><i class="mdi mdi-layers"></i></a>
</div>

<!-- Button mobile view to collapse sidebar menu -->
<div class="navbar navbar-default" role="navigation">
    <div class="container-fluid">

        <!-- Page title -->
        <ul class="nav navbar-nav list-inline navbar-left">
            <li class="list-inline-item">
                <button class="button-menu-mobile open-left">
                    <i class="mdi mdi-menu"></i>
                </button>
            </li>
            <li class="list-inline-item">
                <h4 class="page-title"><?php echo e($title); ?></h4>
            </li>
        </ul>

    </div><!-- end container -->
</div><!-- end navbar -->
</div>
<!-- Top Bar End --><?php /**PATH C:\xampp\htdocs\SIAP-DINPER\resources\views/layouts/topbar.blade.php ENDPATH**/ ?>